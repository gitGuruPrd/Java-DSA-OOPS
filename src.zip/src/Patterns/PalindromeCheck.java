package Patterns;

import java.util.Scanner;

public class PalindromeCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		sc.close();
//		int b=0 ,rem;
//		while(N>0){
//			rem=N%10;
//			b=10*b+rem;
//			N/=10;
//		}
////		System.out.println(b);
//		if(N==b) {
//			System.out.println(true);
//		}else {
//			System.out.println(false);
//		}
		int r,sum=0,temp;    
		  int n=N;//It is the number variable to be checked for palindrome  
		  
		  temp=n;    
		  while(n>0){    
		   r=n%10;  //getting remainder  
		   sum=(sum*10)+r;    
		   n=n/10;    
		  }    
		  if(temp==sum)    
		   System.out.println(true);    
		  else    
		   System.out.println(false);    
		}  
	}


