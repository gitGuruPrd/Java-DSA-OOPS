package Patterns;

import java.util.Scanner;

public class CheckNumbersequence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int N =sc.nextInt();
		int i=0;
		boolean isdec=true;
		int prev =sc.nextInt();
		boolean ans=true;
		while(i<N-1) {
			int curr = sc.nextInt();
			if(curr ==prev) {
				System.out.println(false);
				return;
				
			}else if(curr>prev) {
				isdec=false;
			}else if(curr<prev) {
				if(ans&&isdec) {
					
				}else {
					System.out.println(false);
					return;
				}
			}
			prev=curr;
			i++;
		}
		System.out.println(ans);
	}

}
