package Patterns;

import java.util.Scanner;

public class BinaryToDecimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * 



import java.util.Scanner;

public class Main {
public static void main(String[] args) {
// initialize the Scanner class to read input from the user
Scanner s = new Scanner(System.in);


// Read the binary number from the user
int n = s.nextInt();

// Initialize variables to convert the binary number to decimal
int dec_value = 0;
int base = 1;
int temp = n;

// Use a while loop to iterate through each digit in the binary number
while (temp > 0) {
  int last_digit = temp % 10; // Get the last digit of the binary number
  temp = temp / 10; // Update the binary number by removing the last digit
  
  dec_value += last_digit * base; // Add the current digit to the decimal value
  base = base * 2; // Update the base to the next power of 2
}

// Print the decimal equivalent of the binary number
System.out.println(dec_value);
}
}
		 */
		
		Scanner sc = new Scanner(System.in);
		int N= sc.nextInt();
		sc.close();
		int dec=0;
		int n=0;
for(int i=0;N>=0;i++) {
	n=N%2;
	dec=dec*2+n;
	N=N/10;
	
}
System.out.println(dec);
	}

}
