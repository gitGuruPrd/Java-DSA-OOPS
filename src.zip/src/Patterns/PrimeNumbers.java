package Patterns;

import java.util.Scanner;

public class PrimeNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		sc.close();
		int i,j,n;
	for(i=2;i<=N;i++) {
		for(j=2;j<=i;j++) {
			if(i%j==0 && i!=2) {
				break;
			}else if(i==2){
				System.out.println(i);
			}else if(i-1==j) {
				System.out.println(i);
			}
		}
	}
		

	}

}
