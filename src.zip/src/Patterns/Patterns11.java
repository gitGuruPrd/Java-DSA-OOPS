package Patterns;

import java.util.Scanner;

public class Patterns11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		sc.close();
		int i = 1;
		/*
		 * Print the following pattern for the given number of rows.
Pattern for N = 4
___1
__232
_34543
4567654



The dots represent spaces
		 */
		while(i<=N) {
			int sp=0;
			while(sp<N-i) {
				System.out.print(" ");
				sp++;
			}
			int num=i;
			int j=0;
			while(j<i) {
				System.out.print(num);
				num++;
				j++;
				
			}
			int dec=2*i-2;
			while(dec>=i) {
				System.out.print(dec);
				dec--;
			}
			System.out.println();
			i++;
		}
	}

}
