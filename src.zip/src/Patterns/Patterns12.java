package Patterns;
import java.util.*;


public class Patterns12{
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int N =sc.nextInt();
		sc.close();
		int i = 0;
		/*
		 * Print the following pattern for the given number of rows.
Note: N is always odd.


Pattern for N = 5
__*
_***
*****
_***
__*



The dots represent spaces.
		 */
	i=1;
	int n=(N+1)/2;
//	1 sts part
	while(i<=n) {
		int spaces=n-i;
		while( spaces>0) {
			System.out.print(" ");
			spaces--;
		}
		int star=2*i-1;
		while(star>0) {
			System.out.print('*');
			star--;
		}
	System.out.println();
	i++;
	}
//	2 part
	n=N-n;
	 i =n;
	while(i>=0) {
		int spaces = n-i+1;
		while(spaces>0) {
			System.out.print(" ");
			spaces--;
		}
		int star = 2*i-1;
		while(star>0) {
			System.out.print('*');
			star--;
		}
		System.out.println();
		i--;
	}
	
		
	}
}
