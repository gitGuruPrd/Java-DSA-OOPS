package Patterns;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
 * Write a program to generate the reverse of a given number N. Print the corresponding reverse number.
Note : If a number has trailing zeros, then its reverse will not include them. For e.g., reverse of 10400 will be 401 instead of 00401.
 */
		Scanner sc =new Scanner(System.in);
		int N=sc.nextInt();
		sc.close();
	int r,i=0,rev=0,n;
//	System.out.println(1/10);
	while(N%10==0&N!=0) {
		N/=10;
	}
	for(i=0;N>0;i++) {
		r=N%10;
		rev = rev*10+r;
		N=N/10;
	}
	System.out.println(rev);
	}

}
