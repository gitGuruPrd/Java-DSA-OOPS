package Patterns;

import java.util.Scanner;

public class Patterns15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*     1=1
 * 	   1+2=3
 * 		1+2+3=6
 *      1+2+3+4=10	
 */
	
	Scanner sc=new Scanner(System.in);
	int N=sc.nextInt();
	sc.close();
	int i = 1;
			while(i<=N) {
				int num=1;
				int sum =num;
				int plus=i-1;
				System.out.print(num);
				while(plus>0) {
					num++;
					System.out.print('+');
					System.out.print(num);
//					sum=sum+num;
					sum+=num;
					plus--;
				}
				System.out.print('=');
				System.out.print(sum);
				System.out.println();
				i++;
			}
	}

}
