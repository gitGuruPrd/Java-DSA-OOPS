package Patterns;

import java.util.Scanner;

public class Patterns5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
 * Print the following pattern for the given N number of rows.
Pattern for N = 4
Print the following pattern for the given N number of rows.
Pattern for N = 4
    1
   12
  321
 4321       

 */
		Scanner sc = new Scanner(System.in);
		int N= sc.nextInt();
		sc.close();
		int i =1;
		while(i<=N) {
			int j =0;
			int sp = i;
			while(sp<N) {
				System.out.print(" ");
				sp++;
			}
			while(j<i) {
				System.out.print(j+1);
				j++;
			}
			System.out.println();
			i++;
		}
		
	
	
	}

}
