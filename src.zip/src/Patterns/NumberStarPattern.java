package Patterns;

import java.util.Scanner;

public class NumberStarPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		sc.close();
	int i=0;
	while(i<N) {
		for(int j=1,st=N;j<=N;j++,st--) {
			if(N-i==j) {
				System.out.print('*');
				continue;
			}
			System.out.print(st);
		}
		System.out.println();
		i++;
	}

	}}
