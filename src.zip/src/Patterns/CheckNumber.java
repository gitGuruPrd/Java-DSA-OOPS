package Patterns;

public class CheckNumber {
	public static boolean checkNumber(int input[], int x) {
		/* Your class should be named Solution
		 * Don't write main().
		 * Don't read input, it is passed as function argument.
		 * Return output and don't print it.
	 	 * Taking input and printing output is handled automatically.
		*/
		if(input.length==0){
			return false;
		}
		if(input[0]==x){
			return true;
		}
		
		int[] sm=new int[input.length-1];
		for(int i=1;i<input.length;i++){
			sm[i-1]=input[i];

		}

		boolean ispresent=checkNumber(sm, x);
		return ispresent;

	
		

		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[]arr= {1,2,3,4,5,98};
int x=3;
System.out.println(checkNumber(arr, x));
	}

}
