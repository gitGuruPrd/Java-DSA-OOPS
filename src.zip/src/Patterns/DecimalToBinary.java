package Patterns;

import java.util.Scanner;
import java.math.*;

public class DecimalToBinary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		sc.close();
		int i=0;
		long b =0L,num=0L,r,pow=1L;
	/*	while(N>0){
			r=N%2;
			N=N/2;
		b=b*10+r;
				++i;
			
		}
		
		
		
		Input = number
binary_number=0, pv=1
While number is greater than 0:
 rem = number % 2
binary_number += rem* pv
pv *= 10;
number = number / 2
print(binary_number)
		int j=i;
	while(j-1>0) {
		r=b%2;
		b/=10;
		while(j-1>0) {
			pow=pow*10;
			j--;
			
		}
		n=n+r*pow;
		j--;
	}
		int n=N;
		while(n>0) {
			n/=2;
			i++;
		}
		int j=0;
		while(N>0&&j<i) {
			
			r=N%2;
			N/=2;
		
			b=pow*b+r;
			
		}
	 */
		long B_Number = 0L;
        int cnt = 0;
        while (N != 0) {
            int rem = N % 2;
            long c = (long)Math.pow(10, cnt);
            B_Number += rem * c;
            N /= 2;
 
            // Count used to store exponent value
            cnt++;
        }
 
        System.out.println(B_Number);
	}

}
