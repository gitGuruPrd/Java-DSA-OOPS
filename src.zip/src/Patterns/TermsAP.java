package Patterns;

import java.util.Scanner;

public class TermsAP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Write a program to print first x terms of the series 3N + 2 which are not multiples of 4.
		 */
		Scanner sc= new Scanner (System.in);
		int N =sc.nextInt();
		sc.close();
		for(int i=1,j=1,n;j<=N;i++) {
			n=3*i+2;
			if(n%4!=0) {
				System.out.print(n+" ");
				j++;
			}
			
		}
	}

}
