package Patterns;

import java.util.Scanner;

public class Rectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int n=sc.nextInt();
		sc.close();
		int count=0;
		for(int i=1;i<=n;i++) {
			int w=0;
			int no=1;
			int j=1;
			int rno=n;
//			reducing no loop
			while(i!=j) {
				System.out.print(rno);
				rno--;
				j++;
			}
			if(i==j) {
				w=n-count;
				count++;
//				j=1
				while(no<2*w) {
					System.out.print(w);
					no++;
				}
			}
		j=j+no-1;
//			System.out.println(j);
			int ino=w;
//			increasing no loop
			while(j<2*n) {
				++ino;
				System.out.print(ino);
				j++;
			}
			
			
			System.out.println();
		}
		int reg=2*n-1;
		int m=2;
		for(int i=n+1;i<=reg;i++) {
			int j=reg;
			int rno=n;
			int sno=1;
			while(i!=j) {
				System.out.print(rno);
				rno--;
				j--;}
			if(i==j) {
				while(sno<2*m) {
					System.out.print(m);
					sno++;
				}
				m++;
			}
			int ino=m;
			j=j-sno+1;
			while(j>0) {
				System.out.print(ino);
				ino++;
				j--;
				
			}
			System.out.println();
			
		}

	}

}
