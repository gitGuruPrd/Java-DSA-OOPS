package Patterns;

import java.util.Scanner;

public class SquareRoot{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scanner sc = new Scanner(System.in);
		
		/*
		 * Given a number N, find its square root. You need to find and print only the integral part of square root of N.
For eg.if number given is 18, answer is 4.
		 */
		Scanner sc = new Scanner (System.in);
		int N = sc.nextInt();
		sc.close();
		int i=1,j=i+1,sq,number;
//int squarenxt=j*j;
//for(;square<=N||squarenxt<=N;i++,j++) {
//		if(square==N) {
//			System.out.println(i);
//			break;
//		}else if(squarenxt==N) {
//			System.out.println(j);
//			break;
//		}
//		
//		}
		if(N==0) {
			System.out.println(0);
			return;
		}
while(i<=N) {
	sq=i*i;
	if(sq==N) {
		System.out.println(i);
		break;
	}else if(sq>N) {
		System.out.println(i-1);
		break;
	}
	i++;
}


	}

}
