package Patterns;

import java.util.Scanner;

public class Pattern2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
 * Print the following pattern for the given N number of rows.
Pattern for N = 3
 A
 BB
 CCC
 * */
 Scanner sc = new Scanner(System.in);
 int N;
 N= sc.nextInt();
 sc.close();
 int i = 0;
 while(i<=N) {
	 int j =0;
	 while(j<i) {
	 System.out.print((char)(('A'+i-1)));
	 j++;
	
 }
	 System.out.println();
	 i++;}
	}

}
