package Patterns;

import java.util.Scanner;

public class Patterns8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		sc.close();
		int i=1;
		
		while(i<=N) {
			int space=0;
			while(space<N-i) {
				System.out.print(" ");
				space++;
			}
			char num=(char)('1'+i-1);
			int j=0;
			while(j<i) {
				System.out.print((char)(num+j));
				j++;
			}
			/*
			 * Print the following pattern for the given number of rows.
Pattern for N = 4
___1
__232
_34543
4567654



The dots represent spaces
			 */
			
			int count = i-1;
			num =(char)('1'+2*i-2);
			while(count>0) {
				
						System.out.print((char)(num-j));
				count--;
				j++;
				
			}
			System.out.println();
			i++;
		}
		
	}

}
