package Patterns;

import java.util.Scanner;

public class Patterns6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
 * Print the following pattern for the given N number of rows.
Pattern for N = 4
4444
333
22
1
 */
		
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		sc.close();
		int i =1;
		while(i<=N) {
			int j = 0;
			while(j<N-i+1) {
				System.out.print(N-i+1);
				j++;
			}
			System.out.println();
			i++;
		}
	}

}
