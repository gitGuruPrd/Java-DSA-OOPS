package Patterns;

import java.util.Scanner;

public class SumOrProduct {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int N=sc.nextInt();
		int C=sc.nextInt();
		sc.close();
		int result=1,i;
		
		for(i=2;i<=N&&C==1;i++) {
			result = result +i;

		}
		
		for(i=1;i<=N&&C==2;i++) {
			result*=i;
		}
		if(C!=1 && C!=2) {
			System.out.println(-1);
			return;
		}else if(N==0) {
			System.out.println(0);
			return;
		}
		System.out.println(result);
				
	}

}
