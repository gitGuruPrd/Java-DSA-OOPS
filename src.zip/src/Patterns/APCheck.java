package Patterns;

import java.util.Scanner;

public class APCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		
		int prev =sc.nextInt();
		int curr =sc.nextInt();
		int i=0;
		boolean ans=true;
		boolean isap=true;
//		int d=prev-curr;
		int d=curr-prev;
		while(i<N-2) {
		prev=curr;
		curr=sc.nextInt();
			if(curr-prev!=d) {
				System.out.println(false);
				return;
		
		}
			prev=curr;
			i++;
			
		}
		System.out.println(true);
	}

}
