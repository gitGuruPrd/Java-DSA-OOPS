package Patterns;

import java.util.Scanner;

public class Patterns7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
 * Print the following pattern
Pattern for N = 4
  *
 ***
*****

The dots represent spaces.
 */
		Scanner sc = new Scanner(System.in);
		int i =1;
		int N =sc.nextInt();
		sc.close();
		while(i<=N) {
			int j = 0;
			int space = 0;
			
			while(space<N-i) {
				System.out.print(" ");
				space++;
			}
			while(j<i) {
				System.out.print('*');
				j++;
			}
			int star=1;
			while(star<i) {
				System.out.print('*');
				star++;
				
			}
			System.out.println();
			i++;
			
		}
	
		
	}
	
	
	
}

