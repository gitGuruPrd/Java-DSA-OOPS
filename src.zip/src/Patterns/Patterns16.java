package Patterns;

import java.util.Scanner;

public class Patterns16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		sc.close();
		int i=0;
		int n=1;
		while(i<N) {
			++i;
			int j=1;
//			int p=1;
			while(j<=N){
//reseting n =1: 
				
				if(n<2*N) {
					System.out.print(n);
				}else {
					n=1;
					System.out.print(n);
				}
				n=n+2;
				
				++j;
			
			
//			j++;
			}
//			
			System.out.println();
//			i++;
			n=1+2*i;
			
			
		}

	}

}
