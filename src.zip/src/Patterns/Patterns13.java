package Patterns;

import java.util.Scanner;

public class Patterns13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		sc.close();
		/*
		 * 
*
*1*
*121*
*12321*
*121*
*1*
*
		 */
		
	int i=1;
//	N=2*N;
	int n = N+1;
	while(i<=n) {
		int num =1;
		System.out.print('*');
		while(num<i) {
			System.out.print(num);
			num++;
		}
		int dec = i-2;
		while(dec>0) {
			System.out.print(dec);
			dec--;
		}
		if(i>1) {
			System.out.print('*');
		}
		System.out.println();
		i++;
	}
	i=0;
	while(i<=N) {
		System.out.print('*');
		int j =N;
		while(j>=1) {
			System.out.print(j);
			j--;
		}
		if(i<1)System.out.print('*');
		i++;
		
	}
	
		

	}

}
