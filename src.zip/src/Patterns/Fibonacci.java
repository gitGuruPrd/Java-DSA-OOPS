package Patterns;

//import java.nio.Buffer;
import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		sc.close();
		int n=1,lt=1,st=1;
		if(N==1 || N==2) {
			n=1;
		}else {
		for(int i=3;i<=N;) {
		n=lt+st;
		st=lt;
		lt=n;
		i++;
		}}
		System.out.println(n);
		
		
			
	}

}
