package Patterns;

import java.util.Scanner;

public class RectangulsrNumbers {
/*
 *  33333
	32223
	32123
	32223
	33333
	for i in range(1, n+1, 1):
    for up in range(1, i, 1):
        print(n-up+1,end = '')
        
    for j in range(i, 2*n-i+1, 1):
        print(n-i+1,end = '')
    
    for lp in range(2*n-i, 2*n-1, 1):
        print(lp-n+2,end = '')
    
    print()


for i in range(n-1, 0, -1):
    for up in range(1, i, 1):
        print(n-up+1,end = '')
        
    for j in range(i, 2*n-i+1, 1):
        print(n-i+1,end = '')
    
    for lp in range(2*n-i, 2*n-1, 1):
        print(lp-n+2,end = '')
    
        
    print()
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int n=new Scanner(S)
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		sc.close();
//		int n=4;
		for(int i=1;i<n+1;i++) {
//			System.out.print(n);
		
			        for(int up=1;up<i;i++) {
			        	System.out.print(n-up+1);
			        }
			       
			            for(int j=i;j<2*n-i+1;i++) {
			            	System.out.print(n-i+1);
			            }
			            
			                for(int lp=2*n-i;lp<2*n-1;lp++) {
			                	System.out.print(lp-n+2);
			                }
			            
			
			System.out.println();
		}
	
	}

}
