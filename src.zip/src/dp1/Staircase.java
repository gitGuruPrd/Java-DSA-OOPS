package dp1;

/*A child runs up a staircase with 'n' steps and can hop either 1 step, 2 steps or 3 steps at a time. Implement a method to count and return all possible ways in which the child can run-up to the stairs.

Detailed explanation ( Input/output format, Notes, Images )
 Constraints :
0 <= n <= 10 ^ 4

Time Limit: 1 sec
Sample Input 1:
4
Sample Output 1:
7
Sample Input 2:
10
Sample Output 2:
*/public class Staircase {
	public static int stairCase(int n) {
		int[] dp =new int[n+1];
		return stairCase(n,dp);
	}
	private static int stairCase(int n, int[] dp) {
	if(dp[n]!=0) {
		return dp[n];
	}
		if(n==0) {
			dp[n]=0;
			return dp[n];
		}
		if(n==1) {
			dp[n]=1;
			return dp[1];
		}
		if(n==2) {
			dp[n]=2;
			return dp[n];
		}
		if(n==3) {
			dp[3]=4;
			return dp[n];}
		
		int ans=stairCase(n-1,dp)+stairCase(n-2,dp)+stairCase(n-3,dp);
		dp[n]=ans;
		return dp[n];
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
