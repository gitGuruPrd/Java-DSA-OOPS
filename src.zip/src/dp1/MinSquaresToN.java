package dp1;

public class MinSquaresToN {
	
	
	
	public static  int minSquares(int n) {
		if(n==0) {
			return 0;
		}
		int minAns=Integer.MAX_VALUE;
		for(int i=1;i*i<=n;i++) {
			int currAns=1+minSquares(n-i*i);
			if(minAns>currAns) {
				minAns=currAns;
			}
			
		}
		int myAns=1+minAns;
		return minAns;
	}
	public static int improvised(int n, int[] dp) {
	if(n==0) {
		return 0;
		
	}
	int minAns=Integer.MAX_VALUE;
	for(int i=1;i*i<=n;i++) {
		int currenAns;
		if(dp[n-i*i]==-1) {
			
		 currenAns=improvised(n-i*i,dp);
			dp[n-i*i]=currenAns;
			
		}else {
			currenAns=dp[n-i*i];
		}
		if(minAns>currenAns) {
			minAns=currenAns;
		}
		
	}
	int myAns=1+minAns;
	return myAns;
	
	
	}
	public static void main(String[] args) {
		int n=41;
		int dp[] =new int[n+1];
		for(int i=0;i<dp.length;i++){ 
			dp[i]=-1;
		}
int ans=improvised(n,dp);
System.out.println(ans);
	}

}
