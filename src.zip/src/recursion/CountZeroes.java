package recursion;

public class CountZeroes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
