package Linkedlist;

public class DoublyLinkList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
