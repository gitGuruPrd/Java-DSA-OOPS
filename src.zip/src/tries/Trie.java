package tries;

import java.util.ArrayList;

class TrieNode{
	char data;
	boolean isTerminal;
	TrieNode children[];
	int childCount;
	
	public TrieNode(char data) {
		this.data=data;
		this.isTerminal=false;
		this.children=new TrieNode[26];
		this.childCount=0;
	}
}
public class Trie {
private TrieNode root;
public Trie() {
	root=new TrieNode('\0');
}
//recurssive
private void addHelper(TrieNode root,String word) {
	if(word.length()==0) {
		root.isTerminal=true;
		return;
	}
	int childIndex=word.charAt(0)-'A';//get index of first letter
	TrieNode child=root.children[childIndex];
	if(child==null) {
		child =new TrieNode(word.charAt(0));
		root.children[childIndex]=child;
		root.childCount++;
	}
	addHelper(child, word.substring(1));
}
public void add(String word) {
	addHelper(root, word);
	
	}
private boolean searchHelper(TrieNode root,String word) {
	if(word.length()==0) {
		return root.isTerminal;
	}
	int childIndex=word.charAt(0)-'A';
	TrieNode child=root.children[childIndex];
	
	if(child==null) {
		return false;
	}
	return searchHelper(child, word.substring(1));
	
}
public boolean search(String word) {
	return searchHelper(root, word);
}
private void removeHelper(TrieNode root,String word) {
	if(word.length()==0) {
		root.isTerminal=false;
		return;
	}
	int childIndex=word.charAt(0)-'A';
	TrieNode child=root.children[childIndex];
	if(child==null) {
		return;
	}
	removeHelper(child, word.substring(1));
	if(!child.isTerminal && child.childCount==0) {
		root.children[childIndex]=null;
		root.childCount--;
	}
}
public void remove(String word) {
	removeHelper(root, word);
}


public void autoComplete(ArrayList<String> input,String pattern) {
	for(String str:input) {
		add(str);
	}
	int flag=0;
	TrieNode temp=root;
	int index=0;
	TrieNode outer=root;
	for(int i=0;i<pattern.length();i++) {
		index=pattern.charAt(i)-'a';
		if(temp.children[index]!=null) {
			outer=temp;
			temp=temp.children[index];
		}else {
			flag=1;
			break;
		}
	}
	if(flag==1) {
		return;
	}
	index=pattern.charAt(0)-'a';
	print(temp,pattern.substring(0,pattern.length()-1));
	
}
public static void print(TrieNode root,String output) {
	if(root==null) {
		return;
	}
	output+=root.data;
	if(root.isTerminal) {
		System.out.println(output);
	}
	for(int i=0;i<26;i++) {
	print(root.children[i],output);
	}
}
}
/*
 * //class TrieNode{
	char data;
	boolean isTerminating;
	TrieNode children[];
	int childCount;

	public TrieNode(char data) {
		this.data = data;
		isTerminating = false;
		children = new TrieNode[26];
		childCount = 0;
	}
}


public class Trie {

	private TrieNode root;
	private int numWords;

	public Trie() {
		root = new TrieNode('\0');
		numWords = 0;
	}
	

	public void remove(String word){
		if(remove(root, word)) {
			numWords--;
		}
	}
	

	private boolean remove(TrieNode root, String word) {
		if(word.length() == 0){
			if(root.isTerminating) {
				root.isTerminating = false;
				return true;
			}
			else {
				return false;
			}
		}
		int childIndex = word.charAt(0) - 'a';
		TrieNode child = root.children[childIndex];
		if(child == null){
			return false;
		}
		boolean ans = remove(child, word.substring(1));
		// We can remove child node only if it is non terminating and its number of children are 0	

		if(!child.isTerminating && child.childCount == 0){
			root.children[childIndex] = null;
			child = null;
			root.childCount--;
		}
		return ans;
	}

	private boolean add(TrieNode root, String word){
		if(word.length() == 0){
			if(root.isTerminating) {
				return false;
			}
			else {
				root.isTerminating = true;
				return true;
			}
		}		
		int childIndex = word.charAt(0) - 'a';
		TrieNode child = root.children[childIndex];
		if(child == null){
			child = new TrieNode(word.charAt(0));
			root.children[childIndex] = child;
			root.childCount++;
		}
		return add(child, word.substring(1));
	}

	public void add(String word){
		if(add(root, word)) {
	j		numWords++;
		}
	}
	
	public int countWords() {
		// Write your code here
		return numWords;
	}
	
}
*********************************************************************************************************************
*Problem statement
Given a list of n words and a pattern p that we want to search. Check if the pattern p is present the given words or not. Return true if the pattern is present and false otherwise.

Detailed explanation ( Input/output format, Notes, Images )
Input Format :
The first line of input contains an integer, that denotes the value of n.
The following line contains n space-separated words.
The following line contains a string, that denotes the value of the pattern p.
Output Format :
The first and only line of output contains true if the pattern is present and false otherwise.
Constraints:
0 <= n <= 10^5
Time Limit: 1 sec
Sample Input 1 :
4
abc def ghi cba
de
Sample Output 1 :
true
Sample Input 2 :
4
abc def ghi hg
hi
Sample Output 2 :
true
import java.util.ArrayList;

class TrieNode{

	char data;
	boolean isTerminating;
	TrieNode children[];
	int childCount;

	public TrieNode(char data) {
		this.data = data;
		isTerminating = false;
		children = new TrieNode[26];
		childCount = 0;
	}
}


public class Trie {

	private TrieNode root;
	public int count;
	public Trie() {
		root = new TrieNode('\0');
	}

	public boolean search(String word){
		return search(root, word);
	}

	private boolean search(TrieNode root, String word) {
		if(word.length() == 0){
			return true;
		}
		int childIndex = word.charAt(0) - 'a';
		TrieNode child = root.children[childIndex];
		if(child == null){
			return false;
		}
		return search(child, word.substring(1));
	}
	private boolean add(TrieNode root,String word) {
		if(word.length() == 0){
			if(root.isTerminating) {
				return false;
			}
			else {
				root.isTerminating = true;
				return true;
			}
		}
		int childIndex = word.charAt(0) - 'a';
		TrieNode child = root.children[childIndex];
		if(child == null){
			child = new TrieNode(word.charAt(0));
			root.children[childIndex] = child;
			root.childCount++;
		}
		return add(child, word.substring(1));
		
	}
	public void add(String word) {
		
	}

	public boolean patternMatching(ArrayList<String> vect, String pattern) {
        // Write your code here}
		for(String str:vect) {
			for(int i=0;i<str.length();i++) {
				add(str.substring(i));
			}
		}
		return search(root,pattern);
		
	}
	}
         
	*/
	

 