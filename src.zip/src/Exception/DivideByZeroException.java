package Exception;
// this calass inherits Exception class not object class
public class DivideByZeroException extends Exception {

}
