package priorityQueues;

public class Element<T> {
	
	T value;
	int priority;
	public Element(T value,int priority) {
		this.priority=priority;
		this.value=value;
	}
}
