package priorityQueues;

public class CheckMaxHeap {
	/*
	 * Given an array of integers, check whether it represents max-heap or not. Return true if the given array represents max-heap, else return false.
	 * 
	 */	
	public static boolean maxHeap(int[] arr) {
		int n= arr.length;
		int parentIndex=0;
		
		for(int i=0;i<n/2;i++) {
			int leftChildIndex=2*parentIndex+1;
			int rightChildIndex=2*parentIndex+2;
			if(leftChildIndex<n) {
				if(arr[leftChildIndex]>arr[parentIndex]) {
					return false;
				}
			}
			if(rightChildIndex<n) {
				if(arr[rightChildIndex]>arr[parentIndex]) {
					return false;
				}
			}
			parentIndex++;
		}
		
		return true;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr={42,20,18,6,14,11,9,4};
System.out.println(maxHeap(arr));
	}

}
