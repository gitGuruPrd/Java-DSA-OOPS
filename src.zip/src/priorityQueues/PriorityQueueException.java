package priorityQueues;

public class PriorityQueueException extends Exception {

}
