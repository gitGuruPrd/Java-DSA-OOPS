package priorityQueues;
import java.util.Arrays;

public class KthLargest {
	/*
	 * Problem statement
Given an array 'arr' of random integers and an integer 'k', return the kth largest element in the array.
	 */	
	public static int kthLargest(int n, int[] input, int k) {
		// Write your code here
		Arrays.sort(input);
		for (int i : input) {
			System.out.println(i);
		}
		return input[n-k];
		

	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		int[]arr={3,2,5,1,4};
		System.out.println(kthLargest(5, arr, 1));
	}

}
