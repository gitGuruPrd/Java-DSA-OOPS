package Array;

public class CodeMergeTwoSortedArrays {
public static int[] mergeTwoArrays(int[]arr1,int[]arr2) {
	int[] arr=new int[arr1.length+arr2.length];
	int k=0;
	while(k<arr.length) {
		for(int = 0;j<)
	}
	return arr;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
