package graphs;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.*;

public class Graphs {
	private static void dfTraversal(int[][] adjMatr,int currentVertex,boolean visited[]) {
		visited[currentVertex]=true;
		
		System.out.print(currentVertex + " ");
		for(int i=0;i<adjMatr.length;i++) {
			
			if(adjMatr[currentVertex][i]==1&&(visited[i]==false)) {
				dfTraversal(adjMatr,i,visited);
			}
			
		}
	}
	public static void dfTraversalPract(int[][] adjMatr,int currentVertex,boolean []visited) {
		visited[currentVertex]=true;
		System.out.println(currentVertex+" ");
		for(int i=0;i<adjMatr.length;i++) {
			if(adjMatr[currentVertex][i]==1 && visited[i]==false) {
				dfTraversalPract(adjMatr,i,visited);
			}
		}
		
	}
	public static void depthFirstTraversal(int[][] adjMatr) {
		boolean visited[]=new boolean[adjMatr.length];
		dfTraversal(adjMatr,0,visited);
		boolean visiPract[]=new boolean[adjMatr.length];
		dfTraversalPract(adjMatr,0,visiPract);
	}
	public static void breadthFirstTraversal(int[][] adjMatr) {
//		queue of pending vertices
		Queue<Integer> pendingVertices=new LinkedList<Integer>();
		boolean visited[]=new boolean[adjMatr.length];
		visited[0]=true;
		pendingVertices.add(0);
		while(!pendingVertices.isEmpty()) {
			int currentVertex=pendingVertices.poll();
			System.out.print(currentVertex+" ");
			for(int i=0;i<adjMatr.length;i++) {
				if(adjMatr[currentVertex][i]==1 && !visited[i]) {
//					i is unvisited neighbor of currentVertex
					pendingVertices.add(i);
					visited[i]=true;
				}
			}
		}
		
		
		
	}
	public static void printHelper(int edges[][], int sv,boolean visited[]){
        Queue<Integer> q = new LinkedList<>();
        q.add(sv);
        visited[sv]=true;
        while(q.size()!=0){
            int firstelem = q.remove();
            System.out.print(firstelem+" ");
            for(int i=0; i<edges.length; i++){
                if(edges[firstelem][i]==1 && !visited[i]){
                    q.add(i);
                    visited[i]=true;
                }       
            }
        }   
    }
	/*
	 * public static boolean hasPath(int[][] edges,int V1, int V2,boolean visited[]){
        if(edges[V1][V2]==1)
            return true;
        Queue<Integer> q=new LinkedList<>();
        q.add(V1);
        visited[V1]=true;
        while(!q.isEmpty()){
            int n=q.remove();
            for(int i=0;i<edges.length;i++)
            {
             if(edges[n][i]==1 && !visited[i])
             {
                 q.add(i);
                 visited[i]=true;
             }
            }
        }
        if(visited[V2]==true)
            return true;
        else
            return false;
    }
	 */
    // we have to deal with both connected and non connected
    public static void print(int edges[][]){
        boolean visited[] = new boolean[edges.length];
        for(int i=0; i< edges.length; i++){
            if(!visited[i]){
                printHelper(edges, i, visited);   
            }
        }
    }
    
    public static boolean hasPath(int adjMatr[][],int sv,int ev,boolean []visited) {
    	if(sv>adjMatr.length-1 || ev>adjMatr.length-1) {return false;
    	
    	}
    	if(adjMatr[sv][ev]==1) {
    		return true;
    	}
    	Queue<Integer> pendingVertices=new LinkedList<Integer>();
    	visited[sv]=true;
    	pendingVertices.add(sv);
    	while(!pendingVertices.isEmpty()) {
    		int front=pendingVertices.poll();
    		for(int i=0;i<adjMatr.length;i++) {
    			if(adjMatr[front][i]==1 &&!visited[i]) {
    				if(i==ev) {
    					return true;
    				}else {
    					visited[i]=true;
    					pendingVertices.add(i);
    				}
    			}
    		}
    	}
    	return false;
    	
    }
    public static boolean hasPath(int [][]adjMatrx,int sv,int ev) {
    	boolean visited[]=new boolean[adjMatrx.length];
    	return hasPath(adjMatrx,sv,ev,visited);
    }
    public static void bfsDisconnected(int[][] adjMatr) {
    	boolean visited[]=new boolean[adjMatr.length];
    	
    	for(int i=0;i<adjMatr.length;i++) {
    		
                if(!visited[i]){
                    printHelper(adjMatr, i, visited); 
                    System.out.println();
                }
            }
    	}
    public static boolean isConnected(int[][] adjMatr,int s) {
    	boolean[] visited=new boolean[adjMatr.length];
    	printHelper(adjMatr,s,visited);
    	for(boolean boo:visited) {
    		if(!boo) {
    			return false;
    		}
    	}
    	return true;
    }
//    public static List<Integer> getPath(int[][] adjMatr,int s,int e){
//    	if(s==e) {
//    		ArrayList<Integer> ans= new ArrayList<Integer>();
//    		ans.add(s);
//    		return ans;
//    		
//    		
//    	}
//    	
//    	for(int i=0;i<adjMatr.length;i++ ){ 
//    		for(int j=0;j<adjMatr.length;j++) {
//    			List<Integer> nextAns=getPath(adjMatr,i,j);
//    			if(adjMatr[i][j]==1) {
//    				nextAn
//    			}
//    		}
//    	}
//    	
//    	
//    }
    public static ArrayList<Integer> getPathBFS(int[][] adjMatrix,int s,int e ){
    	Queue<Integer> queue=new LinkedList<>();
    	queue.add(s);
    	boolean []visited=new boolean[adjMatrix.length];
    	HashMap<Integer,Integer>map=new HashMap<>();
    	map.put(s,-1);
    	visited[s]=true;
    	boolean pathFound=false;
    	while(!queue.isEmpty()) {
    		int currentVertex=queue.poll();
    		for(int i=0;i<adjMatrix.length;i++) {
    			if(adjMatrix[currentVertex][i]==1 && !visited[i]) {
    				queue.add(i);
    				visited[i]=true;
    				map.put(i,currentVertex);
    				if(i==e) {
    					pathFound=true;
    					
    					break;
    				}
    				
    			}
    		}
    		
    	}
    	if(pathFound) {
			ArrayList<Integer>list=new ArrayList<>();
			int currentVertex=e;
			while(map.get(currentVertex)!=-1) {
			list.add(e);
			int parent=map.get(currentVertex);
			currentVertex=parent;
		}
			return list;
			}else {
				return null;
			}
    	
    }
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner sc= new Scanner(System.in);
 int n=sc.nextInt();
 int e =sc.nextInt();
 int adjMatr[][]=new int[n][n];
  for(int i=0;i<e;i++) {
	  int v1=sc.nextInt();
	  int v2=sc.nextInt();
	  adjMatr[v1][v2]=1;
	  adjMatr[v2][v1]=1;
  }
//  for(int i=0;i<n;i++) {
//	  for(int j=0;j<n;j++) {
//	  System.out.print(adjMatr[i][j] + " ");
//	  }
//	  System.out.println();
//  }
//  depthFirstTraversal(adjMatr);
//  breadthFirstTraversal(adjMatr);
//  print(adjMatr);
//		String[] strNums;
//		strNums=sc.nextLine().split("\\s");
//		int n= Integer.parseInt(strNums[0]);
//		int e=Integer.parseInt(strNums[1]);
//		int edges[][]=new int[n][n]; //Space O(V^2)
//		for(int i=0;i<e;i++) {
////			creating adjacency Matrix
//			String[] strNums1;
//			strNums1 =sc.nextLine().split("\\s");
//			int fv=Integer.parseInt(strNums1[0]);
//			int sv=Integer.parseInt(strNums1[1]);
//			edges[fv][sv]=1;
//			edges[sv][fv]=1;
//			
//		}
//		String[] strNums1;
//		strNums1=sc.nextLine().split("\\s");
////		checking the path between sorce and end vertices sv and ev
//		int sv=Integer.parseInt(strNums1[0]);
//		int ev=Integer.parseInt(strNums1[1]);
		ArrayList<Integer> path=getPathBFS(adjMatr,0,2);
		
//		for(int s:path) {
//			System.out.print(s+" ");
//		}
//		System.out.println(hasPath(edges,sv,ev));
		boolean visited[]=new boolean[adjMatr.length];
		for(int i=0;i<adjMatr.length;i++) {
			
		}
		print(adjMatr);
		System.out.println(isConnected(adjMatr,0));
 
	}

}
