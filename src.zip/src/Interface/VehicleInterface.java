package Interface;

interface  VehicleInterface {
//public ,final and static by default -Interface
	public void print();
}
