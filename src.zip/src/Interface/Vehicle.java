package Interface;

public class Vehicle implements VehicleInterface {

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Inside Vehicle\nshould implement all the abstract methods");
	}

}
