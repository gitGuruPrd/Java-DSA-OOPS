package recurssion3;

import java.util.ArrayList;
import java.util.List;
public class PrintSubsetSumToK {



	
		public static void printSubsetsSumTok(int input[], int k) {
			// Write your code here
	List<Integer> current=new ArrayList<>();

			// printSubsets(input, 0, 0, k, current);
			helper(input, k, new int[0], 0);
		}
		public static void printSubsets(int[] arr, int i, int sum, int target, List<Integer> current) {
	    if (sum == target) {
	      // Print current subset if sum matches target
	      for (int num : current) {
	        System.out.print(num + " ");
	      }
	      System.out.println();
	      return;
	    }

	    if (i == arr.length || sum > target) {
	      return; // Base cases: reached end or exceeded target sum
	    }

	    // Include current element
	    current.add(arr[i]);
	    printSubsets(arr, i + 1, sum + arr[i], target, current);
	    current.remove(current.size() - 1); // Backtrack: remove included element

	    // Exclude current element
	    printSubsets(arr, i + 1, sum, target, current);
	  }
	  private static void helper(int[] input,int k,int[] output,int currentIndex){
		  if(currentIndex==input.length){
			  if(k==0){
				  for(int j:output){
					  System.out.print(j+" ");
				  }
				  System.out.println();
				  return;
			  }else{
				  return;
			  }
		  }
		// call while including element
		int[] newArr=new int[output.length+1];
		int i=0;
		for(;i<output.length;i++){
		newArr[i]=output[i];
		}
		newArr[i]=input[currentIndex];
		helper(input, k,output, currentIndex+1);
		helper(input, k-input[currentIndex], newArr, currentIndex+1);


	  }
	/*
	helper(input, k-input[currentIndex], newArr, currentIndex+1);
	*/

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
printSubsetsSumTok(new int[] {5,1,2,6,7,3,4}, 9);
	}

}
