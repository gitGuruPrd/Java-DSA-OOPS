package recurssion3;

public class StairCase {
	
	/*
	 * //
	 * find the number of ways in which n number stairs can be crossed using 1 step, 2 step or 3 step
	 */	 
	public static long stairCase(int n,long[] dp) {
		if(dp[n]!=0) {
			return dp[n];
		}
		if(n<=2) {
			dp[n]=n;
			return dp[n];
		}
		if(n==3) {
			dp[n]=4;
			return dp[n];
		}
		long ans=stairCase(n-1, dp)+stairCase(n-2,dp)+stairCase(n-3, dp);
		dp[n]=ans;
		return ans;
	}
	public static int iterativeStairCse(int n) {
		if(n<=2) {
			return n;
		}
		long[] dp =new long[n+1];
		dp[0]=0;
		dp[1]=1;
		dp[2]=2;
		dp[3]=4;
		for(int i=4;i<=n;i++) {
			dp[i]=dp[i-1]+dp[i-2]+dp[i-3];
		}
		return (int)dp[n];
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		long[] dp=new long[n+1];
		System.out.println(stairCase(5, new long[5+1]));
	}

}
