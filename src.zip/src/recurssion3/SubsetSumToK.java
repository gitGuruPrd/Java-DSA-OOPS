package recurssion3;

public class SubsetSumToK {
	/*
	 * //
	 * 
	 * 
	 * Problem statement Given an array A of size n and an integer K, return all
	 * subsets of A which sum to K.
	 * 
	 * Subsets are of length varying from 0 to n, that contain elements of the
	 * array. But the order of elements should remain same as in the input array.
	 * 
	 * 
	 * Note : The order of subsets are not important.
	 * 
	 * 
	 * Detailed explanation ( Input/output format, Notes, Images ) Constraints : 1
	 * <= n <= 20
	 * 
	 * Sample Input : 9 5 12 3 17 1 18 15 3 17 6 Sample Output : 3 3 5 1 public
	 * class solution {
	 * 
	 * // Return a 2D array that contains all the subsets which sum to k public
	 * static int[][] subsetsSumK(int input[], int k) { // Write your code here
	 * 
	 * } }
	 * 
	 * 
	 */ 
	private static int[][] subsetsSumK(int input[],int si,int k){
		if(si==input.length) {
			if(k==0) {
				return new int[1][0];
			}else {
				return new int[0][0];
			}
		}
		int[][] smallArray1=subsetsSumK(input,si+1,k);
		int[][] smallArray2=subsetsSumK(input,si+1, k-input[si]);
		int[][] ans=new int[smallArray1.length+smallArray2.length][];
		int index=0;
		for(int i=0;i<smallArray1.length;i++) {
			ans[index++]=smallArray1[i];
		}
		for(int i=0;i<smallArray2.length;i++) {
			ans[index]=new int[smallArray2[i].length+1];
			ans[index][0]=input[si];
			for(int j=0;j<smallArray2[i].length;j++) {
				ans[index][j+1]=smallArray2[i][j];
			}
			index++;
		}
		
		return ans;
		
	}
	
	public static int[][] subsetsSumK(int input[], int k) {
		return subsetsSumK(input, 0,k);

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
