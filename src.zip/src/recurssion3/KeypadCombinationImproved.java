package recurssion3;

/*

Sample Input:
23
Sample Output:
ad
ae
af
bd
be
bf
cd
ce
cf
*/public class KeypadCombinationImproved {
	static String[] arr=new String[0];
	static int i=0;
public static String getOptions(int n) {
	switch(n) {
	case 1:
		return "abc";
	case 2:
		return "def";
	case 3:
		return "ghi";
	case 4:
		return "jkl";
	case 5:
		return "mno";
	case 7:
		return "pqrs";
	 
	}
	return "";
}
	public static void combinations(int input, String soFar) {
		if(input==0) {
			arr[i++]=soFar;
			return;
	}
		int lastDigit=input%10;
		int nextInput=input/10;
		String lastDigitOptions=getOptions(lastDigit);
		for(int i=0;i<lastDigitOptions.length();i++) {
			combinations(nextInput,lastDigitOptions.charAt(i)+soFar);
		}
		}
		
	public static int[][] subsets(int input[]) {
		// Write your code here
		return subsetsHelper(input,0);
	}
    
    private static int[][] subsetsHelper(int[] input, int startIndex)
    {
        if (startIndex==input.length)
        {
            return new int[1][0];
        }
        int[][] temp = subsetsHelper(input, startIndex+1);
        //System.out.println("Length of 2D matrix: "+temp.length);
        int[][] smallOutput = new int[temp.length*2][];
        
        for (int i=0;i<temp.length;i++)
        {
            smallOutput[i] = new int[temp[i].length];
            int[] smallTemp = temp[i];
            for (int j=0;j<temp[i].length;j++)
            {
                smallOutput[i][j]=smallTemp[j];
            }
        }
        
        for (int i=0;i<temp.length;i++)
        {
            smallOutput[i+temp.length] = new int[temp[i].length+1];
            smallOutput[i+temp.length][0]=input[startIndex];
            int[] smallTemp = temp[i];
            for (int j=1;j<=temp[i].length;j++)
            {
                smallOutput[i+temp.length][j]=smallTemp[j-1];
            }
        }
        /*
        for (int i=0;i<smallOutput.length;i++)
        {
            int[] temp1 = smallOutput[i];
            for (int j=0;j<temp1.length;j++)
            {
                System.out.print(temp1[j]+" ");
            }
            System.out.println();
        }
        System.out.println();
        */
        return smallOutput;
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		combinations(237, "");
	}

}

	

}
