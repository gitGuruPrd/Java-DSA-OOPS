package recurssion3;

public class MinimumInArray {
	public static int minInArray(int[]input,int startIndex) {
		if(startIndex==input.length) {
			return Integer.MAX_VALUE;
		}
		int minSmaallArray=minInArray(input, startIndex+1);
		if(input[startIndex]<minSmaallArray) {
			return input[startIndex];
		}else{
			return minSmaallArray;
		}
	}
	public static void printMin(int[] a) {
		int min=minInArray(a, 0);
		System.out.println(min);
	}
	public static void printMin2(int[]a,int startIndex,int minSoFar) {
		if(startIndex==a.length) {
			System.out.println(minSoFar);
			return;
		}
		if(a[startIndex]<minSoFar) {
			minSoFar=a[startIndex];
		}
		printMin2(a,startIndex+1,minSoFar);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {3,4,5,7,1};
		System.out.println(minInArray(arr, 0));
		printMin2(arr,0,Integer.MAX_VALUE);
	}

}
