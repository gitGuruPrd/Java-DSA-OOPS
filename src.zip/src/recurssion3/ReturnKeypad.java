package recurssion3;

import java.util.Scanner;

/*Problem statement
Given an integer n, using phone keypad find out all the possible strings that can be made using digits of input n.

Return empty string for numbers 0 and 1.

Note :
1. The order of strings are not important.
2. Input and output has already been managed for you. You just have to populate the output array and return the count of elements populated in the output array.
Detailed explanation ( Input/output format, Notes, Images )
Input Format :
Integer n
Output Format :
All possible strings in different lines
Constraints :
1 <= n <= 10^6

Sample Input:
23
Sample Output:
ad
ae
af
bd
be
bf
cd
ce
cf
*/

public class ReturnKeypad {
		public static String getOptions(int n) {
			switch(n) {
			case 1:
				return "abc";
			case 2:
				return "def";
			case 3:
				return "ghi";
			case 4:
				return "jkl";
			case 5:
				return "mno";
			case 7:
				return "pqrs";
			 
			}
			return "";
		}
	public static String[] keypadCombinations(int n) {
		if(n==0) {
			String [] output=new String[1];
			output[0]="";
			return output;
		}
		String[] smallOutPut=keypadCombinations(n/10);
		int lastDigit =n%10;
		String lastDigitOptions=getOptions(lastDigit);
		String[] output=new String[smallOutPut.length * lastDigitOptions.length()];
		int k=0;
		for(int i=0;i<smallOutPut.length;i++) {
			for(int j=0;j<lastDigitOptions.length()
					;j++) {
				output[k]=smallOutPut[i]+lastDigitOptions.charAt(j);
				k++;
			}
		}
		return output;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s =new Scanner(System.in);
System.out.println("Enter Number");
int input =s.nextInt();
String[] output=keypadCombinations(input);
for(String str:output) {
	System.out.println(str);
}
	}

}
