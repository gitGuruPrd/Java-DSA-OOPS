package recurssion3;

public class MinimumNoSquares {
	/*
	 * //Minimum Number Of Squares
	 * 
	 * Send Feedback
	 * 
	 * Given an integer N, find and return the count of minimum numbers required to
	 * represent N as a sum of squares.
	 * 
	 * That is, if N is 4, then we can represent it as: (1^2 + 1^2 + 1^2+12) and
	 * (2^2). The output will be 1, os 1 is the minimum count of numbers required to
	 * represent N as sum of squares.
	 */ 
	public static int minSquaresToN(int n) {
//		if(n==0) {
//			return 0;
//		}
//		if(n==1) {
//			return 1;
//		}
//		
//		int count=Integer.MAX_VALUE;
//		for(int i=1;i<n;i++) {
//			count=Math.min(count, 1+minSquaresToN(n-1*i));
//		}
//		return count;
		int[] dp= new int[n+1];
		return helper(n,dp);
	}
//	memoization
	public static int helper(int n, int[] dp) {
		if(dp[n]!=0) {
			return dp[n];
		}
		if(n==0) {
			return 0;
		}
		if(n==1) {
			return 1;
		}
		int ways=Integer.MAX_VALUE;
		int i=1;
		for(;i*i<=n;i++) {
			ways=Math.min(ways,1+helper(n-i*i,dp));
		}
		dp[n]=ways;
		
		return dp[n];
		
	}
//	iterative version
	public static int iterative(int n) {
		int []dp=new int[n+1];
		dp[0]=0;
		for(int i=1;i<=n;i++) {
			int minAns=Integer.MAX_VALUE;
			for(int j=1;j*j<=i;j++) {
				
				int curAns=1+dp[i-(j*j)];
				if(minAns>curAns) {
					minAns=curAns;
				}
				
			}
			dp[i]=minAns;
		}
		return dp[n];
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(minSquaresToN(41));
System.out.println(iterative(41));
	}

}
