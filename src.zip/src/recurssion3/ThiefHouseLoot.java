package recurssion3;

public class ThiefHouseLoot {
//	Loot Houses
	 
	/*
	 * Send Feedback
	 * 
	 * A thief wants to loot houses. He knows the amount of money in each house. He
	 * cannot loot two consecutive houses. Find the maximum amount of money he can
	 * loot.
	 * 
	 * Input format:
	 * 
	 * The first line of input contains an integer value of 'n'. It is the total
	 * number of houses.
	 * 
	 * The second line of input contains 'n' integer values separated by a single
	 * space denoting the amount of money each house has.
	 * 
	 * Output format:
	 * 
	 * Print the the maximum money that can be looted.
	 * 
	 * Constraints:
	 * 
	 * 0<n<= 10^4
	 * 
	 * Time Limit: 1 sec
	 */
	public static int maxHouseLoot(int[] houses) {
		int[] dp=new int[houses.length+1];
		return helperDP(houses,0,dp);
	}
	private static int helperDP(int[] houses, int i, int[] dp) {
		if(i>=houses.length) {
			return 0;
		}
		
		if(dp[i]!=0) {
			return dp[i];
		}
		int ans1=houses[i]+helperDP(houses, i+2, dp);
		int ans2=houses[i]+helperDP(houses, i+1, dp);
		dp[i]=Math.max(ans1, ans2);
		return dp[i];
	}
	private static int helperRecursion(int[] houses, int i) {
		if(i>=houses.length) {
			return 0;
		}
		
		int ans1=houses[i]+helperRecursion(houses,i+2);
		int ans2=helperRecursion(houses,i+1);
		return Math.max(ans1, ans2);
	}
	public static int iterative(int[] houses) {
		
		int[] dp=new int[houses.length+1];
		int n=houses.length;
		
		if(n<=0) {
			return 0;
		}
		dp[0]=houses[0];
		dp[1]=Math.max(dp[0], houses[1]);
		for(int i=2;i<houses.length;i++) {
			dp[i]=Math.max(dp[i-1], dp[i-2]+houses[i]);
		}
		return dp[n-1];
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(maxHouseLoot(new int[]{1,2,3,4,5,6,7,8}));
	}

}
