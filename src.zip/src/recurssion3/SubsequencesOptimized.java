package recurssion3;

public class SubsequencesOptimized {
	public static void printSubsequence(String str,String soFar) {
		 if(str.length()==0) {
			 
			 System.out.println(soFar);
			 return;
		 } 
		 printSubsequence(str.substring(1),soFar+str.charAt(0));
		 printSubsequence(str.substring(1), soFar);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
printSubsequence("abc", "");
	}
 
}
