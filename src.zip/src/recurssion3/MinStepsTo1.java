package recurssion3;

public class MinStepsTo1 {
	/*
	 * given a positive integer find the minimum no of steps required it to 1 can
	 * perform any of the following steps:1subtract 1 from it i.e n-1 step 2 if its
	 * divisible by 2 i.e n%2==0 step 3 if its divisible by i.e n%3==0 then n=n/3
	 */
	private static int countMinimumBruteForce(int n) {
		if(n==1) {
			return 0;
		}
		int way1=1+countMinimumBruteForce(n-1);
		int way2=Integer.MAX_VALUE;
		if(n%2==0) {
			way2=1+countMinimumBruteForce(n/2);
		}
		int way3=Integer.MAX_VALUE;
		if(n%3==0) {
			way3=1+countMinimumBruteForce(n/3);
		}
		return Math.min(way1, Math.min(way2, way3));
	}
	
	public static int helper(int n,int[]dp) {
		if(dp[n]!=0) {
			return dp[n];
		}
		if(n<=1) {
		dp[n]=0;
		return 0;
		}
		int way1=1+countMinimumBruteForce(n-1);
		int way2=Integer.MAX_VALUE;
		if(n%2==0) {
			way2=1+countMinimumBruteForce(n/2);
		}
		int way3=Integer.MAX_VALUE;
		if(n%3==0) {
			way3=1+countMinimumBruteForce(n/3);
		}
		dp[n]= Math.min(way1, Math.min(way2, way3));
		return dp[n];
		
	}
	public static int iterative(int n) {
		int[] dp =new int[n+1];
//		base case
		dp[0]=0;
		dp[1]=0;
	for(int i=2;i<=n;i++) {
		int way1=1+dp[i-1];
		int way2=Integer.MAX_VALUE;
		if(i%2==0) {
			way2=1+dp[i/2];
		}
		int way3=Integer.MAX_VALUE;
		if(i%3==0) {
			way3=1+dp[i/3];
		}
		dp[i]=Math.min(way1, Math.min(way2, way3));
	}
	return dp[n];
		
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;
System.out.println(helper(n, new int[n+1]));
System.out.println(iterative(n));
	}

}
