package recurssion3;

public class PermutationsOfString {
	/*
	 * //Problem statement
Given a string, find and return all the possible permutations of the input string.

Note :
The order of permutations are not important.
Sample Input :
abc
Sample Output :
abc
acb
bac
bca
cab
cba
char[] ch = str.toCharArray();
 
        // Swapping using XOR operation
        ch[i] = (char)(ch[i] ^ ch[j]);
        ch[j] = (char)(ch[i] ^ ch[j]);
        ch[i] = (char)(ch[i] ^ ch[j]);
 
        return String.valueOf(ch);
	 */	
	public static String[] permutationOfString(String input,String permutation){
		// Write your code here
		
		char toSwap=input.charAt(si);
		for(int i=0;i<input.length();i++) {
			if(si==i) {
				continue;
			}
			
			
		}
		
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	

}
