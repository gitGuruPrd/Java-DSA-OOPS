package BinaryTrees;

public class Btree <T>{
public Btree left;
public Btree right;
public T data;
public Btree(T data) {
	this.data=data;
}
}
