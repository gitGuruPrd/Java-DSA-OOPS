package HashMaps;

import java.util.ArrayList;
import java.util.HashMap;

public class MaxFrequencyNumber {
		public static int getMostFreqNum(int[] arr) {
			HashMap<Integer,Integer> map=new HashMap<Integer, Integer>();
			int maxFreq=0,maxKey=Integer.MIN_VALUE;
			for(int i=0;i<arr.length;i++) {
				if(map.containsKey(arr[i])) {
			int value=map.get(arr[i]);
			value++;
			map.put(arr[i], value);
			if(value>maxFreq) {
				maxFreq=value;
				maxKey=arr[i];
			}
				}else {
					map.put(arr[i], 0);
					
				}
				
			}
			return maxKey;
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int[] arr= {1,2,5,4,1,4,5,6,7,3,1,2,4,2,5,6,7,2,3,1,2};
			System.out.println(getMostFreqNum(arr));
			}

}
