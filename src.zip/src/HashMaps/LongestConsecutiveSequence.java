package HashMaps;

import java.util.HashMap;

public class LongestConsecutiveSequence {
	public static String getUniqueChar(String str) {
		HashMap<Character, Integer> map=new HashMap<Character, Integer>();
		String newStr="";
		for(int i=0;i<str.length();i++) {
			char c=str.charAt(i);
			if(map.containsKey(c)) {
				map.put(c,map.get(c)+1);
			}else {
				newStr+=c;
				map.put(c, 1);
			}
		}
		return newStr;
	}
	
public static void main(String[] args) {
	System.out.println(LongestConsecutiveSequence.getUniqueChar("codingNinjas"));
}
}
