package HashMaps;

import java.util.ArrayList;
import java.util.HashMap;



public class LongestSequence {
	
	/*
	 * Problem statement
You are given an array of unique integers that contain numbers in random order. You have to find the longest possible sequence of consecutive numbers using the numbers from given array.

You need to return the output array which contains starting and ending element. If the length of the longest possible sequence is one, then the output array must contain only single element.

Note:
1. Best solution takes O(n) time.
2. If two sequences are of equal length, then return the sequence starting with the number whose occurrence is earlier in the array.
Detailed explanation ( Input/output format, Notes, Images )
Constraints :
0 <= n <= 10^6
Time Limit: 1 sec
Sample Input 1 :
13
2 12 9 16 10 5 3 20 25 11 1 8 6 
Sample Output 1 :
8 12 
Explanation:The longest consecutive sequence here is [8, 9, 10, 11, 12]. So the output is the start and end of this sequence: [8, 12].
Sample Input 2 :
7
3 7 2 1 9 8 41
Sample Output 2 :
7 9
Explanation:There are two sequences of equal length here: [1,2,3] and [7,8,9]. But since [7,8,9] appears first in the array (7 comes before 1), we return this sequence. So the output is [7,9].
public static ArrayList<Integer> longestConsecutiveIncreasingSequence(int[] arr)
	 */
	
	public  static ArrayList<Integer> getLongestSeq(int[] arr) {
		ArrayList<Integer> arrList= new ArrayList<Integer>();
		if(arr.length==1) {
			 arrList.add(arr[0]);
			 return arrList;
		}
	HashMap<Integer, Boolean> map=new HashMap<>();

	for(int i=0;i<arr.length;i++) {
		map.put(arr[i], true);
	}
	int maxLength=Integer.MIN_VALUE,current,firstNum=Integer.MIN_VALUE,lastNum=Integer.MIN_VALUE,currentStart;
	for(int i=0;i<arr.length;i++) {
		int start=arr[i];
//		check element is repeated
		if(map.get(arr[i])) {
//			element is not repeated
			int currentLength=0;
			current=arr[i];
			currentStart=arr[i];
			
			while(map.containsKey(current)) {
				currentLength++;
				map.put(current, false);
				current++;
			}
			current--;
			if(currentLength>maxLength) {
				arrList.add(0, currentStart);
				maxLength=currentLength;
				if(current!=arr[i]) {
					arrList.add(1,current);
				}
			}
			
			
			
			
			
			
			
		}else {
			continue;
		}
	}
	
	return arrList;
	
	
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr= {15,24,3,12,19,11,16};
		ArrayList<Integer> cl=getLongestSeq(arr);
		System.out.println(cl.get(0)+" "+cl.get(1));
	}

}
