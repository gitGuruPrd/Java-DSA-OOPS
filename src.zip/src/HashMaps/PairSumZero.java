package HashMaps;

import java.util.HashMap;
import java.util.Set;

import Array.printAllPairs;

public class PairSumZero {
/*
 * Given a random integer array A of size N. Find and print the count of pair of elements in the array which sum up to 0.



Note:
Array A can contain duplicate elements as well.
 * 
 * 
	public static int PairSum(int[] input, int size) {
		/* Your class should be named Solution
		 * Don't write main().
		 * Don't read input, it is passed as function argument.
		 * Return output and don't print it.
	 	 * Taking input and printing output is handled automatically.
       
	}
 * 
 */
	
	public static int PairSum(int[]arr,int size) {
//		if(size==0|| size==1) {
//			return 0;
//		}
//		HashMap<Integer,Integer> map= new HashMap<>();
//		int pair=0;
//		for(int i=0;i<size;i++) {
//			if(map.containsKey(arr[i])) { 
//				map.put(arr[i],map.get(arr[i])+1);
//	
//			}
//		int negative=0-(arr[i]);
//		if(map.containsKey(negative)) {
//			if(map.get(negative)>0){
//				
//				++pair;
//				map.put(negative, map.get(negative)-1);
//			}
//			map.put(arr[i], 1);
//		}else {
//			map.put(arr[i], 1);
//		}
//		}
//		Set<Integer> set=map.keySet();
//		for(int key:set) {
//			System.out.print(key+" ");
//		}
//		System.out.println(pair);
//		return pair;
		
		
		if(size==0 || size==1) {
			return 0;
		}
		HashMap<Integer,Integer> map= new HashMap<Integer, Integer>();
		int pair=0;
		for(int i=0;i<size;i++) {
			if(i==0) {
				map.put(arr[i], 1);
				continue;
			}
			if(map.containsKey(-arr[i])) {
//				map.put(arr[i], map.get(arr[i]));
				pair+=map.get(-arr[i]);
			}
			if(map.containsKey(arr[i])) {
				map.put(arr[i], map.get(arr[i])+1);
				continue;
			}
			map.put(arr[i],1);
			
		}
		return pair;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr= {2,3,3,2,2};	
		System.out.println(PairSum(arr,arr.length));
	}

}
