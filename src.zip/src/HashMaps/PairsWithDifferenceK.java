package HashMaps;

import java.util.HashMap;

public class PairsWithDifferenceK {
	

/*
 * Problem statement
You are given with an array of integers and an integer K. You have to find and print the count of all such pairs which have difference K.

Note: Take absolute difference between the elements of the array.

Detailed explanation ( Input/output format, Notes, Images )
Constraints :
0 <= n <= 10^4
Time Limit: 1 sec
Sample Input 1 :
4 
5 1 2 4
3
Sample Output 1 :
2
Explanation
(5,2) and (1,4) are the possible combinations as their absolute difference is 3.
 * 
 */
	public static int getPairs(int[] arr,int k) {
		if(arr.length<=1) {
			return 0;
		}
		HashMap<Integer,Integer> map=new HashMap<>();
		int pair=0;
//		for(int i=0;i<arr.length;i++) {
//			
//				if(i==0) {
//					map.put(arr[i], 1);
//					continue;
//				}
//				if(map.containsKey(Math.abs(arr[i]-k))) {
////					map.put(arr[i], map.get(arr[i]));
//					pair+=map.get(arr[i]);
//				}
//				if(map.containsKey(arr[i])) {
//					map.put(arr[i], map.get(arr[i])+1);
//					continue;
//				}
//				map.put(arr[i],1);
//				
//			}
		
		for(int i=0;i<arr.length;i++) {
			if(map.containsKey(arr[i])) {
				map.put(arr[i], map.get(arr[i])+1);
			}else {
				map.put(arr[i],1);
			}
		}
		for(int i=0;i<arr.length;i++) {
			if(map.containsKey(arr[i]-k)|| map.containsKey(arr[i]+k)) {
				
			}
		}
		
		
		return pair;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {5,1,2,4};
System.out.println(getPairs(arr,3));
	}

}
