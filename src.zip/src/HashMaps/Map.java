package HashMaps;

import java.util.ArrayList;

public class Map <K,V>{
ArrayList<MapNode<K,V>> buckets;
int count;
int numBuckets;



public Map() {
	buckets=new ArrayList<>();
	numBuckets=20;
	for(int i=0;i<numBuckets;i++) {
		buckets.add(null);
	}
}
public int getBucketIndex(K key) {
	int hc=key.hashCode();
	int index=hc%numBuckets;
	return index;
}
// load factor funtion
public double loadFactor() {
	return (1.0*count)/numBuckets;
}
public void insert(K key,V value) {
	int bucketIndex=getBucketIndex(key);
	MapNode<K, V>head=buckets.get(bucketIndex);
	MapNode<K,V> prev = null;

//	check if key is already there
	while(head!=null) {
		if(head.key.equals(key)) {
			head.value=value;
			return;
		}
		head=head.next;
	}
	head=buckets.get(bucketIndex);
MapNode<K, V>newHead=new MapNode<>(key, value);
newHead.next=head;
buckets.set(bucketIndex, newHead);

count++;
double loadFactor=(1.0*count)/numBuckets;
if(loadFactor>0.7) {
	reHash();
}

	
}
//size 
public int size() {
	return count;
}
// get value by key
public V getValue(K key) {
	int bucketIndex=getBucketIndex(key);
	MapNode<K, V> head=buckets.get(bucketIndex);
	while(head!=null) {
		if(head.key.equals(key)) {
			return head.value;
		}
		head=head.next;
	}
	return null;
}

//remove function
public V removeKey(K key) {
	int bucketIndex=getBucketIndex(key);
	MapNode<K, V> head=buckets.get(bucketIndex);
	MapNode<K, V> prev=null;
	while(head!=null) {
		if(head.key.equals(key)) {
			V value=head.value;
		if(prev!=null) {
			prev.next=head.next;
		}else {
			buckets.set(bucketIndex, head.next);
		}
		count--;
		return value;
		
		}
		prev=head;
		head=head.next;
	}
	return null;
}
//rehashing
private void reHash() {
	ArrayList<MapNode<K, V>> temp=buckets;
	buckets=new ArrayList<MapNode<K,V>>();
	for(int i=0;i<2*temp.size();i++) {
		MapNode<K, V> head=temp.get(i);
		while(head!=null) {
			K key=head.key;
			V value=head.value;
			insert(key, value);
			head=head.next;
			
		}
	}
	
	
}

}
