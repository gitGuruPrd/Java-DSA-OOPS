package Queues;

public class QueueFullException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
