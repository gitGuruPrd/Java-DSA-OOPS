package Queues;

import java.util.Queue;

public class Fbbonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//Queue<Integer> q=new Queue<Integer>();

	}

}
