package Tests;

public class NextNumber {

}
