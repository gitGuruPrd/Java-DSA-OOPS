package Tests;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;
/*
 * You have made a smartphone app and want to set its subscription price such that the profit earned is maximised. There are certain users who will subscribe to your app only if their budget is greater than or equal to your price.
You will be provided with a list of size N having budgets of subscribers and you need to return the maximum profit that you can earn.
Lets say you decide that price of your app is Rs. x and there are N number of subscribers. So maximum profit you can earn is :
 */
public class MaximumProfit {
	public static int maxProfit(int budget[]) {
		int l=budget.length;
		Arrays.sort(budget);
		int max=Integer.MIN_VALUE;
		int j=1;
		for(int i=l-1;i>=0;i--) {
			int temp=budget[i]*j;
			if(temp<max) {
				break;
			}
			max=Math.max(max, temp);
			j++;
		}
		return max;
//		int l= budget.length;
//		int profit ;
//		int pri=0;
//		int no;
//		int avg=0,max=0;
//		for(int i=0;i<l;i++) {
//			avg+=budget[i];
//			if(budget[i]>max) {
//				max=budget[i];
//			}
//		}
//		avg/=l;
//		System.out.println(avg);
//		no=0;
////		max=avg;
//		for(int i=0;i<l;i++) {
//			if(budget[i]>=avg && budget[i]<max) {
//				max=budget[i];
//			}
//		}
//		pri=max;
//		System.out.println(pri);
//		no=0;
//		for(int i=0;i<l;i++) {
//			if(budget[i]>=pri) {
//				no++;
//			}int max=
//		}
//		return pri*no;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] arr= {34,78,90,15,67};
//Scanner sc=new Scanner(System.in);
//while()
System.out.println(maxProfit(arr));
	}

}
