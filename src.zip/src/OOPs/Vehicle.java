package OOPs;

public abstract class Vehicle  {
public String color;
int wheels;
public void print() {
	System.out.println("This vehicle has "+wheels+" wheels and color is "+color);
}
public abstract boolean isMotorised() ;
//public abstract b 
}
