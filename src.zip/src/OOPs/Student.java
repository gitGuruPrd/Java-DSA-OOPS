package OOPs;

public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			GetSet st=new GetSet();
			st.name="Kavya";
			st.setId(10);
			System.out.println(st.name+" "+st.getId());
	}

}
