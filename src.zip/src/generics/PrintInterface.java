package generics;

public interface PrintInterface {
void print();
}
