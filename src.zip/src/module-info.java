module fundamentals {
	requires java.desktop;
}