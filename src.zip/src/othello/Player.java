package othello;

public class Player {
private String name;
private char color;

}
