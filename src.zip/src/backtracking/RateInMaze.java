package backtracking;

public class RateInMaze {
	
	public static boolean ratInAMaze(int maze[][]){

		/*Your class should be named Solution. 
		*Don't write main().
	 	*Don't take input, it is passed as function argument.
	 	*Don't print output.
	 	*Taking input and printing output is handled automatically.
		*/ 
	int n =maze.length;
	int path[][]=new int[n][n];
	return solveMaze(maze,0,0,path);
}
	public static boolean solveMaze(int[][] maze,int i, int j,int[][] path) {
//		check if i,j cells are valid or not
		int n=maze.length;
		if(i<0 || i>=n || j<0 || j>=n || maze[i][j]==0 || path[i][j]==1) {
			return false;
		}
//		Include the cell in current path
		path[i][j]=1;
//		Destination cell
		if(i==n-1 && j==n-1 ) {
			for(int p=0;p<n;p++) {
				for(int q=0;q<n;q++) {
					System.out.print(path[p][q]+" ");
				}
				System.out.println();
			}
			 path[i][j]=0;
			
			return true;
		}
//	explore further in all directions
//		top
		if(solveMaze(maze,i-1,j,path)) {
			return true;
		}
//		right
		if(solveMaze(maze, i, j+1, path)) {
			return true;
		}
//		down
		if(solveMaze(maze, i+1, j, path)) {
			return true;
		}
//		left
		if(solveMaze(maze,i,j-1,path)) {
			return true;
		}
		return false;
		
	}
	public static void printPath(int[][] maze,int i, int j,int[][] path) {
//		check if i,j cells are valid or not
		int n=maze.length;
		if(i<0 || i>=n || j<0 || j>=n || maze[i][j]==0 || path[i][j]==1) {
			return ;
		}
//		Include the cell in current path
		path[i][j]=1;
//		Destination cell
		if(i==n-1 && j==n-1 ) {
			for(int p=0;p<n;p++) {
				for(int q=0;q<n;q++) {
					System.out.print(path[p][q]+" ");
				}
				
			}
			System.out.println();
			path[i][j]=0;
			
			return;
		}
//	explore further in all directions
//		top
		printPath(maze,i-1,j,path);
//		right
		printPath(maze, i, j+1, path);
//		down
	printPath(maze, i+1, j, path);
//		left
	printPath(maze,i,j-1,path);
		path[i][j]=0;
		
	}
	public static void printMaze(int[][] maze,int n) {
		int[][] path=new int[n][n];
		printPath(maze,0,0,path);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int maze[][]= {{1,1,1},{1,1,0},{1,1,1}};
//System.out.println(ratInAMaze(maze));
printMaze(maze,maze.length);
	}

}
