package backtracking;

public class NQueens {
	/*
	 * Problem statement You are given N, and for a given N x N chessboard, find a
	 * way to place N queens such that no queen can attack any other queen on the
	 * chess board. A queen can be killed when it lies in the same row, or same
	 * column, or the same diagonal of any of the other queens. You have to print
	 * all such configurations. Detailed explanation ( Input/output format, Notes,
	 * Images ) Sample Input 1: 4 Sample Output 1 : 0 1 0 0 0 0 0 1 1 0 0 0 0 0 1 0
	 * 0 0 1 0 1 0 0 0 0 0 0 1 0 1 0 0
	 */
	public static void NQueens(int n) {
		int board[][]=new int[n][n];
		placeQueens(board,n,0);
	}
	
	private static void placeQueens(int[][] board, int n, int i) {
		// TODO Auto-generated method stub
		int l=board.length;
		
		if(i==n) {
//			check for board configuration
			printArray(board);
			return;
		}
//		board[i][j]=1;
//		for(int col=0;col<l;col++) {
//			
//		}
//		check for all columns
		for(int j=0;j<n;j++) {
			if(isSafe(board,i,j)) {
				board[i][j]=1;
//		check if its safe to place queen
				placeQueens(board,i+1,n);
				board[i][j]=0;
			}
			
			
		}
//		check if its safe to place queen
//		check if its safe to place queen
//		if its safe then place the queen and move to next row
		
//		board[i][j]=0;
//		return;
		
	}
	public static boolean isSafe(int[][]board,int row,int col) {
		int N=board.length;
//		diagonal up
		for(int i=row-1,j=col-1;i>=0 &&j>=0;i--,j--) {
			if(board[i][j]==1) {
				return false;
			}
		}
//		diagoal down
		for(int i=row+1,j=col+1;i<N &&j<N;i++,j++) {
			if(board[i][j]==1) {
				return false;
			}
		}
//		diagonal north east
		for(int i=row-1,j=col+1;i>=0 &&j<N;i--,j++) {
			if(board[i][j]==1) {
				return false;
			}
		}
//	diagona; south west
		for(int i=row+1,j=col-1;i<N && j>=0;i++,j--) {
			if(board[i][j]==1) {
				return false;
			}
		}
//		col up
		for(int i=row-1,j=col;i>=0;i--) {
			if(board[i][j]==1) {
				return false;
			}
		}
//		col down 
		for(int i=row+1,j=col;i<N;i++) {
			if(board[i][j]==1) {
				return false;
			}
		}
		return true;
//		
		
	}
	public static void printArray(int[][] board) {
		int numRows=board.length;
		int numCol=board[0].length;
		
		for(int i=0;i<numRows;i++) {
			for(int j=0;j<numCol;j++) {
				System.out.print(board[i][j]+" ");
			}
		}
		System.out.println();
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
NQueens(5);
	}

}
