package Stacks;

public class StackUse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StackUsingArray stack =new StackUsingArray();
		stack.push();
		stack.top();
		stack.size();
		stack.pop();
	}

}
 