package Stacks;

public class LLNode {
	LLNode prev;
	LLNode next;
	int data;
	public LLNode(int data){
		
	this.data=data;
	

	}
	
}
