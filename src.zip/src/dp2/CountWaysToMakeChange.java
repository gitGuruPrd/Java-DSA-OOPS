package dp2;

public class CountWaysToMakeChange {
	public static int memoization(int[] denomination, int value,int idx, int[][]dp) {
		if(value==0) {
			return 1;
		}
		if(idx==denomination.length || value<0) {
			return 0;
		}
		if(dp[idx][value]!=-1) {
			return dp[idx][value];
		}
		int incl=memoization(denomination, value-denomination[idx], idx, dp);
		int excl=memoization(denomination, value, idx+1, dp);
		dp[idx][value]=incl+excl;
		return dp[idx][value];
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
