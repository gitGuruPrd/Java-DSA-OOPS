package dp2;

public class MinCostPath {

	public static int minCostR(int[][] cost, int i, int j, int[][] dp) {
		int n = cost.length;
		int l = cost[0].length;
		if (i == n - 1 && j == l - 1) {
			return cost[i][j];
		}
		if (i >= cost.length || j >= cost.length) {
			return Integer.MAX_VALUE;
		}

		int ans1, ans2, ans3;
		if (dp[i + 1][j] == Integer.MIN_VALUE) {
			ans1 = minCostR(cost, i + 1, j, dp);
			dp[i + 1][j] = ans1;
		} else {
			ans1 = dp[i + 1][j];
		}
		if (dp[i][j + 1] == Integer.MIN_VALUE) {
			ans2 = minCostR(cost, i, j + 1, dp);
			dp[i][j + 1] = ans2;
		} else {
			ans2 = dp[i][j + 1];
		}
		if (dp[i + 1][j + 1] == Integer.MIN_VALUE) {
			ans3 = minCostR(cost, i + 1, j + 1, dp);
			dp[i + 1][j + 1] = ans3;
		} else {
			ans3 = dp[i + 1][j + 1];
		}
		int myAns = cost[i][j] + Math.min(ans2, Math.min(ans1, ans3));
		return myAns;

	}

	public static int minCost(int[][] cost, int i, int j) {

		int n = cost.length;
		int l = cost[0].length;
		if (i == n - 1 && j == l - 1) {
			return cost[i][j];
		}
		if (i >= cost.length || j >= cost.length) {
			return Integer.MAX_VALUE;
		}

		int ans = cost[i][j]
				+ Math.min(minCost(cost, i + 1, j), Math.min(minCost(cost, i, j + 1), minCost(cost, i + 1, j + 1)));

		return ans;

	}

	public static int iterative(int[][] cost) {
		int m = cost.length;
		int n = cost[0].length;
		int[][] dp = new int[m + 1][n + 1];
		for (int i = 0; i <= m; i++) {
			for (int j = 0; j <= n; j++) {
				dp[i][j] = Integer.MAX_VALUE;

			}
		}

		for (int i = m - 1; i >= 0; i--) {
			for (int j = n - 1; j >= 0; j--) {
				if (i == m - 1 && j == n - 1) {
					dp[i][j] = cost[i][j];
					continue;
				}
				int ans1 = dp[i][j + 1];
				int ans2 = dp[i + 1][j];
				int ans3 = dp[i + 1][j + 1];

				dp[i][j] = cost[i][j] + Math.min(ans1, Math.min(ans2, ans3));
				

			}
		}
		return dp[0][0];
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] cost = { { 5, 7, 2, 4 }, { 1, 8, 1, 3 }, { 6, 2, 9, 5 }, { 1, 6, 2, 8 } };

		int[][] dp = new int[cost.length + 1][cost[0].length + 1];
//extra dp length to avoid index out of bound or conditonal modification
		for (int i = 0; i < dp.length; i++) {
			for (int j = 0; j < dp.length; j++) {
				dp[i][j] = Integer.MIN_VALUE;
			}
		}
		System.out.println(minCost(cost, 0, 0));
		System.out.println(minCostR(cost, 0, 0, dp));
		System.out.println(iterative(cost));

	}

}
