package dp2;

public class SmallestSuperSequence {
	/*
	 * Given two strings S and T with lengths M and N. Find and return the length of
	 * their shortest 'Super Sequence'.
	 * 
	 * The shortest 'Super Sequence' of two strings is defined as the smallest
	 * string possible that will have both the given strings as its subsequences.
	 * 
	 * Note : If the two strings do not have any common characters, then return the
	 * sum of the lengths of the two strings. Detailed explanation ( Input/output
	 * format, Notes, Images ) Constraints : 0 <= M <= 10 ^ 3 0 <= N <= 10 ^ 3
	 * 
	 * Time Limit: 1 sec Sample Input 1 : ab ac Sample Output 1 : 3 Explanation of
	 * Sample Output 1 : Their smallest super sequence can be "abc" which has length
	 * = 3. Sample Input 2 : pqqrpt qerepct Sample Output 2 : 9
	 */
	public static int recurssion(String str1,String str2,int i,int j) {
             
		if(i==str1.length()|| j==str2.length()) {
			if(i!=str1.length()) {
				return str1.length()-1;
			}else if(j!=str2.length()) {
				return str2.length()-j;
			}else {
				return 0;
			}
		}
		if(str1.charAt(i)==str2.charAt(j)) {
			return 0;
		}
		int ans1=recurssion(str1, str2, i+1, j);
		int ans2=recurssion(str1, str2, i, j+1);
		return 1+Math.min(ans1, ans2);
		
		
		
	}
//	be proud this was done by you only
	 public static int recurssion(String str1,String str2,int i,int j,int[][] dp) {
         
			if(i==str1.length()|| j==str2.length()) {
				if(i!=str1.length()) {
					// return str1.length()-1;
					return str1.substring(i).length();
				}else if(j!=str2.length()) {
					// return str2.length()-j;
					return str2.substring(j).length();
				}else {
					return 0;
				}
			}
			if(dp[i][j]!=0){
				return dp[i][j];

			}
			if(str1.charAt(i)==str2.charAt(j)) {
				dp[i][j]= 1+recurssion(str1, str2, i+1, j+1,dp);
			}else{
			int ans1=recurssion(str1, str2, i+1, j,dp);
			int ans2=recurssion(str1, str2, i, j+1,dp);
			dp[i][j]= 1+Math.min(ans1, ans2);
			}
			
			
			
		return dp[i][j];
		}
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
