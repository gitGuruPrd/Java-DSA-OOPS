package dp2;

public class EditDistance {
	/*
	 * Problem statement You are given two strings S and T of lengths M and N,
	 * respectively. Find the 'Edit Distance' between the strings.
	 * 
	 * Edit Distance of two strings is the minimum number of steps required to make
	 * one string equal to the other. In order to do so, you can perform the
	 * following three operations:
	 * 
	 * 1. Delete a character 2. Replace a character with another one 3. Insert a
	 * character Note : Strings don't contain spaces in between.
	 * 
	 * abc dc Sample Output 1 : 2 Explanation to the Sample Input 1 : In 2
	 * operations we can make string T to look like string S. First, insert
	 * character 'a' to string T, which makes it "adc".
	 * 
	 * And secondly, replace the character 'd' of string T with 'b' from the string
	 * S. This would make string T as "abc" which is also string S.
	 * 
	 * Hence, the minimum distance. Sample Input 2 : whgtdwhgtdg aswcfg Sample
	 * Output 2 : 9
	 */
	public static int editDistance(String str1, String str2) {
		
//		delete a character
//		replace a character
//		insert a character
		if(str1.length()==0 || str2.length()==0) {
			return (str1.length()==0)? str2.length():str1.length(); 
		}
		int myAns,ans1=Integer.MAX_VALUE,ans2=Integer.MAX_VALUE,ans3=Integer.MAX_VALUE;
		
//		 when first character is same as first of other string
		
		if (str1.charAt(0)==str2.charAt(0)) {
			myAns=editDistance(str1.substring(1), str2.substring(1));
			
		}else {
//			if deleting from string 1
			ans1=1+editDistance(str1.substring(1), str2);
//		if inserting in string 1
			ans2=1+editDistance(str1, str2.substring(1));
//		if replacing in string 1
			ans3 =1+editDistance(str1.substring(1), str2.substring(1));
			myAns=Math.min(ans1, Math.min(ans2, ans3));
			
			
		}
		return myAns;

		
		
		
	}
	
//	public static int memoization(String str1, String str2, int[][] dp,int i,int j) {
//		if(str1.charAt(i)==str1.charAt(j)) {
//			
//		}
//		
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str1="abc";
		String str2="dc";
		int[][] dp=new int[str1.length()+1][str2.length()+1];
//		for(int i=0;i<=str1.length();i++) {
//			for(int j=0;j<=str2.length();j++)
//		}
	}

}
