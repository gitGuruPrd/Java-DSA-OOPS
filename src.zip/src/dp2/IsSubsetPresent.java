package dp2;

public class IsSubsetPresent {
	static boolean isSubsetPresent(int[] arr,int n, int sum,int idx,boolean dp[][]){
        if(idx==n || sum<0){
            return false;
        }
        if(dp[idx][sum]){
            return dp[idx][sum];
        }
        if(arr[idx]==sum){
            dp[idx][sum]=true;
            return dp[idx][sum];
        }
        dp[idx][sum]= isSubsetPresent(arr, n, sum-arr[idx], idx+1,dp) || isSubsetPresent(arr, n, sum, idx+1,dp);
        return dp[idx][sum];
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.println(isSubsetPresent(new int[]{2,3,4,5},4,5,0,new boolean[5][6] ));
	}

}
