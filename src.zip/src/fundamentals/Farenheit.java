package fundamentals;

import java.util.*;

public class Farenheit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int S, E, W, C, i;
		S = sc.nextInt();
		E = sc.nextInt();
		W = sc.nextInt();
		sc.close();
		i = S;
		while (i <= E) {
			C = (i - 32) * 5 / 9;
			System.out.println(i + " " + C);
			i += W;

		}

	}

}
