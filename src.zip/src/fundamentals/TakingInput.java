package fundamentals;
import java.util.Scanner;

public class TakingInput {
	public static int [] change(int input[]){
		input = new int[5];
		input[3] = 15;
		return input;
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		  int arr[][]=new int[4][5];
//		    for(int i=0;i<5;i++)
//		    {
//		        arr[i][0]=2;
//		    }
//		    System.out.print(arr[3][0]);
//	}
//		String st1="heelo";
//		String st2="dheelo";
//		
//		st1+=st2;
//		System.out.println(st1.length());
//		String st=st1.substring(3,5);
//		int[][] arr = new int [2][2]; 
//		System.out.println(st);
//	    for (int i = 0; i < 2; i++) { 
//	        for (int j = 0; j < 2; j++) { 
//	            System.out.print(arr[i][j] + " "); 
//	        } 
//	    }
//	    String a="coding";
//	    for(int i=2;i<4;i++)
//	    {
//	        System.out.print(a.substring(i)+"/n");
//	    }
//	    
//	    String a1="coding";
//	    for(int i=2;i<5;i++)
//	    {
//	        System.out.print(a1.substring(i-2,i+1));
//	    }
//	    System.out.println(String.MAX_VALUE);
//		char ch='0';
//		int j=ch;
//		
//		System.out.println(j);
		

//			public static void main(String args[]){
//			int arr[] = new int[15];
//			arr=change(arr);
//			System.out.println(arr[7]);
//			}
//		boolean istrue=(10<11);
//		System.out.println(istrue);
//		
	
//		String s=;
//		System.out.println();
//		System.out.println('1'-1);
//		String str="abcd";
//		String s =str.substring(0,3);
//		String s2= str.substring(s.length(),str.length());
		System.out.println(1/10);
		
	
	}
		

	}
