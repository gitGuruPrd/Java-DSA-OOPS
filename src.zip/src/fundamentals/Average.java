package fundamentals;
import java.util.*;

public class Average {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		int m1,m2,m3,avg;
		char n;
		String str =  s.next();
		m1=s.nextInt();
		m2=s.nextInt();
		m3=s.nextInt();
		n =str.charAt(0);
		avg = (m1 +m2+m3)/3;
		int a = Integer.MAX_VALUE;
		long c = Long.MAX_VALUE;
		
		System.out.println(avg+" "+a+" "+ c);
		
	}

}
