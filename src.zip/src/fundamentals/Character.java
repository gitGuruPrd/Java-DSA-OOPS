package fundamentals;

import java.util.*;

public class Character {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		int a=5,b=4;
		  System.out.println(a*=b);//line 1
		  System.out.println(a=(a==b));//line 2
		  System.out.println(a==b);//line 3
	}

}
