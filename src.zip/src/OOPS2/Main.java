package OOPS2;

class Main {
    public static void main(String args[]) {
    Audi a = new Audi();
    }         
}
