package OOPS2;

import OOPs.Vehicle;

public class VehicleUse2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Vehicle v= new Vehicle();
			v.color="pink";
			v.print();

	}

}
