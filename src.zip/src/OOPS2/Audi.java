package OOPS2;

class Audi extends Car {
    Audi() {
    	super();
    System.out.print("This Is Audi ");
    }
} 

