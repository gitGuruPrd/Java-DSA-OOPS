package Strings;

public class CheckPermutation2 {
public static boolean checkPermutation() {
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
