var navMenuAnchorTags=document.querySelectorAll('a');
for(var i=0;i<navMenuAnchorTags.length;i++){
    navMenuAnchorTags[i].addEventListener('click', function(event){
        event.preventDefault();
        var targersectionId=this.textContent.trim().toLowerCase();
        
    })
}